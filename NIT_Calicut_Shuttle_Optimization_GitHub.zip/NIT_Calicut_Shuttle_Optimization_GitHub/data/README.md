# Data

`shuttle_observations_and_analysis.xlsx` is the project workbook. It contains recorded observations, derived analysis sheets, a diagnostic summary, and current/proposed timetable comparison.

Important interpretation notes:
- Regular bus nominal capacity used in the project: 32 passengers.
- AC bus nominal capacity used in the project: 78 passengers.
- Occupancy above 100% reflects observed passenger counts exceeding nominal capacity; it is not a recommended operating target.
- Blank cells mean unavailable/not recorded, not zero.
- Some Excel time cells represent afternoon trips but may display without an AM/PM marker. The script does not use those ambiguous times to infer periods; it uses recorded deviation values and the documented timetable scenario.
