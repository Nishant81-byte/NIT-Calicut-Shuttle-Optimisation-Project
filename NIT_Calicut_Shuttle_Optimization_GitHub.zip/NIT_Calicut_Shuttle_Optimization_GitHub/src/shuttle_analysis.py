"""Descriptive analysis for the NIT Calicut campus shuttle project.

This script reads the observation table in Sheet1 of the project workbook,
calculates summaries only from populated source fields, and compares the
current and proposed 12:00-14:00 scheduled passenger-space supply.
It does not infer missing observations or establish causation.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import pandas as pd

REGULAR_CAPACITY = 32
AC_CAPACITY = 78
CURRENT_REGULAR_TRIPS = 10
CURRENT_AC_TRIPS = 4
PROPOSED_REGULAR_TRIPS = 8
PROPOSED_AC_TRIPS = 4


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--workbook", type=Path,
        default=Path(__file__).resolve().parents[1] / "data" / "shuttle_observations_and_analysis.xlsx",
        help="Path to the project Excel workbook.",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path(__file__).resolve().parents[1] / "outputs",
        help="Directory for generated CSV summaries.",
    )
    return parser.parse_args()


def load_observations(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Workbook not found: {path}")
    book = pd.ExcelFile(path)
    required = {"Sheet1", "Current vs Proposed", "Proposed 12–2 Schedule"}
    missing = required.difference(book.sheet_names)
    if missing:
        raise ValueError(f"Workbook is missing expected sheet(s): {', '.join(sorted(missing))}")

    raw = pd.read_excel(path, sheet_name="Sheet1")
    # The workbook's main observation table ends when the Date field becomes blank;
    # lower rows contain secondary tables and notes, not more rows in this dataset.
    if "Date" not in raw.columns:
        raise ValueError("Sheet1 does not contain the expected 'Date' column.")
    # The first column is reused by secondary tables farther down the sheet;
    # keep only rows whose Date cell is genuinely a date/datetime value.
    parsed_dates = pd.to_datetime(raw["Date"], errors="coerce")
    raw = raw.loc[parsed_dates.notna()].copy()
    raw["Date"] = parsed_dates.loc[raw.index]
    raw["Bus"] = raw["Bus"].astype("string").str.strip()

    numeric_columns = [
        "Delay (minutes)", "Departure Deviation", "Dwell Time (minutes)",
        "Passenger Count", "Capacity",
    ]
    for col in numeric_columns:
        if col in raw.columns:
            raw[col] = pd.to_numeric(raw[col], errors="coerce")
    if "Passenger Count" in raw and "Capacity" in raw:
        raw["Calculated Occupancy (%)"] = (
            raw["Passenger Count"].div(raw["Capacity"].where(raw["Capacity"].ne(0))) * 100
        )
    return raw


def summarize_observations(df: pd.DataFrame) -> pd.DataFrame:
    measures = {
        "Arrival deviation (minutes)": "Delay (minutes)",
        "Departure deviation (minutes)": "Departure Deviation",
        "Dwell time (minutes)": "Dwell Time (minutes)",
        "Passenger count": "Passenger Count",
        "Occupancy (%)": "Calculated Occupancy (%)",
    }
    records = []
    for bus, group in df.groupby("Bus", dropna=False):
        for label, col in measures.items():
            if col not in group.columns:
                continue
            values = group[col].dropna()
            records.append({
                "Bus": "Unknown" if pd.isna(bus) else str(bus),
                "Metric": label,
                "n": int(values.size),
                "Mean": round(float(values.mean()), 2) if not values.empty else pd.NA,
                "Minimum": round(float(values.min()), 2) if not values.empty else pd.NA,
                "Maximum": round(float(values.max()), 2) if not values.empty else pd.NA,
            })
    return pd.DataFrame(records)


def occupancy_observations(df: pd.DataFrame) -> pd.DataFrame:
    cols = [c for c in ["Date", "Day", "Bus", "Passenger Count", "Capacity", "Calculated Occupancy (%)"] if c in df.columns]
    out = df[cols].copy()
    if "Calculated Occupancy (%)" in out:
        out["Over Capacity"] = out["Calculated Occupancy (%)"].gt(100).map({True: "Yes", False: "No"})
        out.loc[out["Calculated Occupancy (%)"].isna(), "Over Capacity"] = "Unknown"
    return out


def capacity_comparison() -> pd.DataFrame:
    current = CURRENT_REGULAR_TRIPS * REGULAR_CAPACITY + CURRENT_AC_TRIPS * AC_CAPACITY
    proposed = PROPOSED_REGULAR_TRIPS * REGULAR_CAPACITY + PROPOSED_AC_TRIPS * AC_CAPACITY
    reduction = current - proposed
    return pd.DataFrame([
        {"Scenario": "Current timetable", "Regular trips": CURRENT_REGULAR_TRIPS,
         "AC trips": CURRENT_AC_TRIPS, "Total departures": CURRENT_REGULAR_TRIPS + CURRENT_AC_TRIPS,
         "Theoretical passenger-spaces": current, "Change vs current (%)": 0.0},
        {"Scenario": "Proposed interleaved timetable", "Regular trips": PROPOSED_REGULAR_TRIPS,
         "AC trips": PROPOSED_AC_TRIPS, "Total departures": PROPOSED_REGULAR_TRIPS + PROPOSED_AC_TRIPS,
         "Theoretical passenger-spaces": proposed,
         "Change vs current (%)": round(-reduction / current * 100, 1)},
    ])


def main() -> int:
    args = parse_args()
    try:
        observations = load_observations(args.workbook)
    except (FileNotFoundError, ValueError, OSError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    args.output_dir.mkdir(parents=True, exist_ok=True)
    summary = summarize_observations(observations)
    occupancy = occupancy_observations(observations)
    capacity = capacity_comparison()

    summary_path = args.output_dir / "observation_summary.csv"
    occupancy_path = args.output_dir / "occupancy_observations.csv"
    capacity_path = args.output_dir / "capacity_comparison.csv"
    summary.to_csv(summary_path, index=False)
    occupancy.to_csv(occupancy_path, index=False)
    capacity.to_csv(capacity_path, index=False)

    print("NIT Calicut Campus Shuttle Optimization")
    print("=" * 42)
    print(f"Workbook: {args.workbook}")
    print(f"Observation rows read from Sheet1: {len(observations)}")
    print("\nDescriptive observations by bus and metric (missing values excluded):")
    print(summary.to_string(index=False))
    print("\n12:00–14:00 theoretical capacity comparison:")
    print(capacity.to_string(index=False))
    print("\nInterpretation guardrails:")
    print("- Passenger-spaces are scheduled capacity, not actual passengers carried.")
    print("- Missing values are excluded, not converted to zero.")
    print("- Small, uneven samples support descriptive findings only; they do not prove causation.")
    print("\nCSV outputs:")
    print(f"- {summary_path}")
    print(f"- {occupancy_path}")
    print(f"- {capacity_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
