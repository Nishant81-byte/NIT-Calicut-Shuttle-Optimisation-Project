# Data dictionary

Definitions below describe the intended meaning of the observation fields. Use the actual workbook column names when tracing individual values.

| Variable | Definition | Unit / type | Calculation or source |
|---|---|---|---|
| Date | Date of the observation | Date | Recorded field observation |
| Day | Day of week | Text | Recorded or derived from date |
| Bus | Bus observed | Category | A/C, Bus 1, Bus 2 |
| Scheduled Departure | Timetable departure time | Time | Published timetable |
| Actual Arrival | Observed arrival time | Time | Field observation |
| Delay (minutes) | Arrival deviation from scheduled time | Minutes; signed | Actual arrival minus scheduled arrival, as recorded in the workbook |
| Actual Departure | Observed departure time | Time | Field observation |
| Departure Deviation | Difference between actual and scheduled departure | Minutes; signed | As recorded in the workbook; positive means later, negative means earlier |
| Dwell Time (minutes) | Time spent at the recorded dwell point before departure | Minutes | Field observation; dwell point described in the project as MBH |
| Passenger Count | Passengers counted on the bus | Passengers | Field observation |
| Capacity | Nominal bus capacity used for comparison | Passengers | 32 for regular buses; 78 for AC bus |
| Occupancy | Passenger load as a share of nominal capacity | Percent | Passenger Count ÷ Capacity × 100 |
| Over-capacity observation | Passenger count exceeds nominal capacity | Boolean/category | Occupancy > 100% |
| Headway | Time between consecutive departures in the same service sequence | Minutes | Current/proposed departure timestamps; actual headway requires reliable actual departure timestamps |
| Theoretical passenger-spaces | Sum of scheduled trips multiplied by nominal capacity | Passenger-spaces per analysis window | Not the same as actual passengers carried |

## Interpretation rules

- Keep raw observations separate from derived calculations.
- Do not replace missing observations with zero.
- Report the number of observations (`n`) with averages where possible.
- Treat observed associations (for example, occupancy and dwell time) as descriptive, not causal evidence.
- No recorded observations in a time period means “unavailable for assessment,” not “no issue.”
